Instructions:

- 1. Load/compile a simple program or directly load a Simple machine language program
	- Choose a premade test program from menu or
	- Enter a program yourself (must be a valid program)
- 2. Run program
- 3. Dump computer (this doesn't change any data, just prints current registers and memory to console for testing purposes)
	- To test compiler you can dump memory before running the program but after load/compile of simple program
	- Compiler also saves generated machine language code to user specified file to load later or to check for correct compilation