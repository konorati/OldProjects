#include "Application.h"


int main(void)
{
	Application app;
	app.runApplication();

	return 0;
}