Instructions:

- Load a program into memory
	- Choose a premade test function from menu or
	- Enter a program yourself (must be a valid program and entered words must be 5 digit integers)
- Run program
- Dump computer (this doesn't change any data, just prints current registers and memory to console for testing purposes)