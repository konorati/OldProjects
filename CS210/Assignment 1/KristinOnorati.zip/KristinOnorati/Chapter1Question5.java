//Kristin Onorati
//Assignment 1 - Chapter 1 - Question 5
//CS 210 - Gandham

//Answers exercise 5 from chapter 1
public class Chapter1Question5 {

	//Creates a different string on six different lines
	public static void main(String[] args) {
		
		System.out.println("A \"quoted\" String is");
		System.out.println("'much' better if you learn");
		System.out.println("the rules of \"escape sequences.\"");
		System.out.println("Also, \"\" represents and empty String.");
		System.out.println("Don't forget: use \\\" instead of \" !");
		System.out.println("'' is not the same as \"");
		

	}

}
